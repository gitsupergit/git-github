package tests;

public class appium {

}
