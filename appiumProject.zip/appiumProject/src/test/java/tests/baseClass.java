package tests;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.apache.tools.ant.taskdefs.WaitFor.Unit;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.BrowserType;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.remote.MobileCapabilityType;
import io.appium.java_client.remote.MobilePlatform;

public class baseClass {
	
	@Test
	public void setup()  {
		try {

			
			DesiredCapabilities dc=new DesiredCapabilities();
			dc.setCapability(MobileCapabilityType.AUTOMATION_NAME, "Appium");
			dc.setCapability(MobileCapabilityType.DEVICE_NAME, "Android");
			dc.setCapability(MobileCapabilityType.APPLICATION_NAME, "Android");
			dc.setCapability(MobileCapabilityType.PLATFORM_VERSION, "5.1.1");
			
			dc.setCapability("appPackage", "com.ebay.mobile");
			dc.setCapability("appActivity", "com.ebay.mobile.activities.MainActivity");
			
			URL url = new URL("http://127.0.0.1:4723/wd/hub");
			AndroidDriver<WebElement> driver=new AndroidDriver<WebElement>(url,dc);
			Thread.sleep(5000);
			
			driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			//Click on SignIn button
			WebElement signIn=driver.findElementById("com.ebay.mobile:id/button_sign_in");
			signIn.click();

			//Username field
			WebElement userName =driver.findElementById("com.ebay.mobile:id/edit_text_username");
			userName.sendKeys(""); //Enter your Username
			
			
			Thread.sleep(2000);
			
			//Password Fielf
			WebElement password=driver.findElementById("com.ebay.mobile:id/edit_text_password");
			password.sendKeys("");  //Enter your Password
			
			signIn.click();
		}
		catch (Exception e) {
			e.printStackTrace();
		}


		
	}
	
	

}
